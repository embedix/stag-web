Zdrojove kody lze zkompilovat v Delphi 6 Personal,
nutna je free komponenta Balmsoft Polyglot a komponenta
IcXMLParser - 16bit (free)
